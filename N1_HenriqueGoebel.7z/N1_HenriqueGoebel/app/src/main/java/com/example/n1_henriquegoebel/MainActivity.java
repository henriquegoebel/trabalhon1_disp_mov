package com.example.n1_henriquegoebel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {

    private EditText etNomeCompleto, etNomeCamiseta, etNumeroCamiseta;
    private RadioGroup rgPe;
    private RadioButton rbCanhoto, rbDestro, rbAmbidestro;
    private CheckBox cbGoleiro, cbLateral, cbZagueiro, cbMeia, cbAtacante;
    private Button btSalvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNomeCompleto = findViewById(R.id.etNomeCompleto);
        etNomeCamiseta = findViewById(R.id.etNomeCamiseta);
        etNumeroCamiseta = findViewById(R.id.etNumeroCamiseta);
        rgPe = findViewById(R.id.rgPe);
        rbCanhoto = findViewById(R.id.rbCanhoto);
        rbDestro = findViewById(R.id.rbDestro);
        rbAmbidestro = findViewById(R.id.rbAmbidestro);
        cbGoleiro = findViewById(R.id.cbGoleiro);
        cbLateral = findViewById(R.id.cbLateral);
        cbZagueiro = findViewById(R.id.cbZagueiro);
        cbMeia = findViewById(R.id.cbMeia);
        cbAtacante = findViewById(R.id.cbAtacante);
        btSalvar = findViewById(R.id.btSalvar);

        //btSalvar.setEnabled(false);

        btSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                salvar();
            }
        });

    }

    private void salvar(){
        Jogador jogador = new Jogador();

        String nomeCompleto = etNomeCompleto.getText().toString();

        if(!nomeCompleto.isEmpty() && !nomeCamiseta.isEmpty() &&...)
    }
}